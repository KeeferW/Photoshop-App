package model;

/**
 * Represents different file types for various images.
 */
public enum FileType {
  ppm, png, jpg, raw, heic
}

package controller;

import java.io.IOException;

/**
 * Represents a controller for the user to run and interact with the Collage operations.
 * Contains the run method that prompts the user to enter commands and starts accepting input.
 */
public interface CollageController {

  /**
   * Displays all commands for a Project.
   *
   * @throws IOException if view cannot be transmitted
   */
  void menu() throws IOException;

  /**
   * Displays commands and begins accepting user input.
   *
   * @throws IllegalStateException if the controller cannot read/write a file
   */
  void run() throws IllegalStateException;

}

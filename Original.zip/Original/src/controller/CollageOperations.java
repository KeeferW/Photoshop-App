package controller;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Interface for different operations the user can run.
 */
public interface CollageOperations {

  /**
   * Creates a new project for the user to add layers or images on.
   * @throws IllegalArgumentException if the input cannot be converted to an int
   * @throws IOException if the view cannot be transmitted
   */
  void newProject() throws IllegalArgumentException, IOException;

  /**
   * Loads an image from the path and names it, once an image is loaded filters can be applied.
   * @throws FileNotFoundException cannot be accessed
   * @throws IOException if view cannot be transmitted
   */
  void load() throws FileNotFoundException, IOException;

  /**
   * Loads an image of png or jpg from the path and names it.
   * @param imagePath - image path
   * @param imageName - name of the image
   * @throws IllegalArgumentException if the path does not exist
   */
  void load(String imagePath, String imageName) throws IllegalArgumentException;

  /**
   * Adds an image ontop of an existing layer.
   * @throws IOException if the view cannot be transmitted
   */
  void addImageToLayer() throws IOException;

  /**
   * Applies a specified filter onto a whole layer.
   * @throws IOException if the view cannot be transmitted
   */
  void setFilter() throws IOException;

  /**
   * Saves the image to the path.
   * @throws IOException if the image cannot be transmitted to the path
   */
  void save() throws IOException;

  /**
   * Displays only the green channel of the pixel.
   * @throws IOException if view cannot be transmitted
   */
  void redComponent() throws IOException;

  /**
   * Displays only the green channel of the pixel.
   * @throws IOException if view cannot be transmitted
   */
  void greenComponent() throws IOException;

  /**
   * Displays only the blue channel of the pixel.
   * @throws IOException if view cannot be transmitted
   */
  void blueComponent() throws IOException;

  /**
   * Brightens an image by getting the maximum value for rgb of every pixel.
   * @throws IOException if view cannot be transmitted
   */
  void brightenValue() throws IOException;

  /**
   * Darken an image by getting the maximum value for rgb of every pixel.
   * @throws IOException if view cannot be transmitted
   */
  void darkenValue() throws IOException;

  /**
   * Create a greyscale image by calculating the luma of every pixel.
   * @throws IOException if view cannot be transmitted
   */
  void brightenLuma() throws IOException;

  /**
   * Darkens an image by calculating the luma of every pixel.
   * @throws IOException if view cannot be transmitted
   */
  void darkenLuma() throws IOException;

  /**
   * Brightens an image by calculating the intensity of every pixel.
   * @throws IOException if view cannot be transmitted
   */
  void brightenIntensity() throws IOException;

  /**
   * Darkens an image by calculating the intensity of every pixel.
   * @throws IOException if view cannot be transmitted
   */
  void darkenIntensity() throws IOException;

  /**
   * Darkens an image by multiplying the L value of a Pixel.
   * @throws IOException if view cannot be transmitted
   */
  void darkenMultiply() throws IOException;

  /**
   * Darkens an image by screening the L value of a Pixel.
   * @throws IOException if view cannot be transmitted
   */
  void brightenScreen() throws IOException;

  /**
   * Differences an image by calculating the difference between the current image and the
   * composite image below it.
   */
  void difference() throws IOException;

  /**
   * Adds an image layer to the project.
   * @throws IOException if view cannot be transmitted
   */
  void addLayer() throws IOException;
}
